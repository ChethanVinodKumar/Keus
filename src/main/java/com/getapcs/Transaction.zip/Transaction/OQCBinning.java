package com.getapcs.Transaction;

import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.getapcs.base.Testbase1;
import com.getapcs.pages.HomePage;

public class OQCBinning  extends Testbase1 {
	
	//Shop Order 
	
	@FindBy(xpath = "(//textarea[@role='combobox'])[1]")
	WebElement fgItemNumber;

	@FindBy(xpath = "(//input[@aria-autocomplete='list'])[1]")
	WebElement shopOrderNum;
	
	@FindBy(xpath = "(//input[@placeholder='Accepted Qty'])[1]")
	WebElement acceptedQty;

	@FindBy(xpath = "//button[normalize-space()='Save']")
	WebElement saveButton;
	
	public OQCBinning() {
	   
	    PageFactory.initElements(driver, this);
	}

//*************OQC Binning Create Page******************
	
	public HomePage OQCBinningCreate() throws InterruptedException {
		// TODO Auto-generated method stub
		System.out.println("//*************OQC Binning Create Page******************");
		driver.navigate().to("https://demo_keus.getapcs.com/engineering/engg-bom/table");
		
	    String tableXpath = "//table[@class='table table-striped']";
	    
	    //Get the first PR number text from table 
	    String fgItemNumber1 = driver.findElement(By.xpath(tableXpath+"/tbody/tr[1]/td[2]")).getText();
	    
	    //Store the element with hard coded PR number 
	    String elementXpath = "(//span[normalize-space()='Item-FG-11-TEST'])[1]";
	    
	    String updatedXpath = elementXpath.replace("Item-FG-11-TEST", fgItemNumber1+"-Test Description");
	    
	    System.out.println(updatedXpath);
	    
	    
	    //***********//
	  
	    
	    driver.navigate().to("https://demo_keus.getapcs.com/transaction/shop-order/table");
		
	    String tableXpath2 = "//table[@class='table table-striped']";
	    
	    //Get the first PR number text from table 
	    String shopOrderNumber = driver.findElement(By.xpath(tableXpath2+"/tbody/tr[1]/td[2]")).getText();
	    
	    //Store the element with hard coded PR number 
	    String elementXpath2 = "(//span[normalize-space()='Item-FG-11-TEST'])[1]";
	    
	    String updatedXpath2 = elementXpath2.replace("Item-FG-11-TEST", shopOrderNumber);
	    
	    System.out.println(updatedXpath2);
	    
	    driver.navigate().to("https://demo_keus.getapcs.com/transaction/create-oqc-binning");

//FG Item Number
	    
		//Verify that  fgItemNumber Field is Displayed or not
		boolean isDisabledfgItemNumberFieldn = !fgItemNumber.isDisplayed(); 
		Assert.assertFalse(isDisabledfgItemNumberFieldn);
		
		js.executeScript("arguments[0].scrollIntoView(true);", fgItemNumber);
		Thread.sleep(5000);
		fgItemNumber.click();
		
		//Verify that  fgItemNumber Field is clickable or not
		WebElement fgItemNumberFieldFocusedElement = driver.switchTo().activeElement();
	    boolean fgItemNumberFieldIsSelected = fgItemNumberFieldFocusedElement.equals(fgItemNumber);
	    Assert.assertTrue(fgItemNumberFieldIsSelected, "fgItemNumber Text Field is not Selected");	    
        
		WebElement fgItemNumberSelect = driver.findElement(By.xpath(updatedXpath));
		
		js.executeScript("arguments[0].click();", fgItemNumberSelect);

//Shop Order Number
		
	  //Verify that  shopOrderNum Field is Displayed or not
  		boolean isDisabledshopOrderNumFieldn = !shopOrderNum.isDisplayed(); 
  		Assert.assertFalse(isDisabledshopOrderNumFieldn);
  		
  		js.executeScript("arguments[0].scrollIntoView(true);", shopOrderNum);
  		shopOrderNum.click();
  		
  		//Verify that  shopOrderNum Field is clickable or not
  		WebElement shopOrderNumFieldFocusedElement = driver.switchTo().activeElement();
  	    boolean shopOrderNumFieldIsSelected = shopOrderNumFieldFocusedElement.equals(shopOrderNum);
  	    Assert.assertTrue(shopOrderNumFieldIsSelected, "shopOrderNum Text Field is not Selected");	  	    
          
  	  WebElement shopOrderNum = driver.findElement(By.xpath(updatedXpath2));
		
		js.executeScript("arguments[0].click();", shopOrderNum);

	
//accepted Qty

		String acceptedQtyxpath = "//label[text()='Accepted FG Qty']/..//input[@class='form-control field2 ng-untouched ng-pristine ng-valid']";
		
		String acceptedQty = driver.findElement(By.xpath(acceptedQtyxpath)).getText();
		
		System.out.println("Project Type is : "+acceptedQty);
		Thread.sleep(2000); 
  			
//Binning 
		
		
		
//Save Button
	     
	     //Verify and Click on Save Button in Create-Item PriceList-Sales Module
	       boolean saveButtonIsDisplayed = saveButton.isDisplayed();
	       assertTrue(saveButtonIsDisplayed, "Save Button is not Displayed");
	       saveButton.click();
	     
		return new HomePage();
	}

}
