package com.getapcs.Transaction;



import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import java.util.List;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.getapcs.base.Testbase1;
import com.getapcs.pages.HomePage;



public class Binning extends Testbase1 {
	
	
	@FindBy(xpath = "(//input[@type='text'])[1]")
	WebElement selectGRINnoDropDown; 
	
	@FindBy(xpath = "//label[text()='Vendor Name']/following-sibling::label[@class='field2']")
	WebElement vendorNameElement; 
	
	@FindBy(xpath = "(//input[@type='text'])[3]")
	WebElement acceptedQty; 
	
	@FindBy(xpath = "(//button[normalize-space()='Binning Locations'])[1]")
	WebElement binning; 
	
	@FindBy(xpath = "//ng-select[@placeholder='Select Project Number']/.//div[@class='ng-select-container ng-has-value']")
	WebElement projectNum; 
	
	@FindBy(xpath = "(//input[@type='text'])[3]")
	WebElement warehouse; 
	
	@FindBy(xpath = "(//span[normalize-space()='HYD-BH-RD5'])[1]")
	WebElement warehouseSelect; 
	
	@FindBy(xpath = "(//input[@type='text'])[4]")
	WebElement location; 
	
	@FindBy(xpath = "(//span[normalize-space()='room no1'])[1]")
	WebElement locationSelect; 
	
	@FindBy(xpath = "(//input[@placeholder='Enter quantity'])[1]")
	WebElement quantity; 
	
	@FindBy(xpath = "(//button[normalize-space()='Add'])[1]")
	WebElement add; 
	
	@FindBy(xpath = "(//button[normalize-space()='Save'])[3]")
	WebElement save; 
	
	@FindBy(xpath = "(//button[normalize-space()='Save'])[2]")
	WebElement save1; 
	public Binning() {
		
		PageFactory.initElements(driver, this);
	}
	
	public HomePage BinningCreatePage() throws Throwable {
		
		driver.navigate().to("https://demo_keus.getapcs.com/transaction/grin/table");
		
        String tableXpath = "//table[@class='table table-striped']";
        
        //Get the first PR number text from table 
        String grinNumber = driver.findElement(By.xpath(tableXpath+"/tbody/tr[1]/td[2]")).getText();
        
        System.out.println(grinNumber);
        
        //Store the element with hard coded PR number 
        String elementXpath = "//span[normalize-space()='031023PR-00002']";
        
        String updatedXpath = elementXpath.replace("031023PR-00002", grinNumber);
        
        System.out.println(updatedXpath);
        
        Thread.sleep(3000);
        
driver.navigate().to("https://demo_keus.getapcs.com/transaction/sales-order/table");
		
	    String tableXpath2 = "//table[@class='table table-striped']";
	    
	    //Get the first PR number text from table 
	    String ProjectNumber = driver.findElement(By.xpath(tableXpath2+"/tbody/tr[1]/td[4]")).getText();
	    
	    //Store the element with hard coded PR number 
	    String elementXpath2 = "(//span[normalize-space()='Item-FG-11-TEST'])[1]";
	    
	    String updatedXpath2 = elementXpath2.replace("Item-FG-11-TEST", ProjectNumber);
	    System.out.println(updatedXpath2);
        
        Thread.sleep(3000);
        
        driver.navigate().to("https://demo_keus.getapcs.com/transaction/binning/create");
        
        //Verify Select GRIN No. Drop Down in IQC Confirmation Create Page
        boolean selectGRINnoDropDownIsDisplayed = selectGRINnoDropDown.isDisplayed();
        assertTrue(selectGRINnoDropDownIsDisplayed, "Select GRIN No. Drop Down is not Displayed.");
        selectGRINnoDropDown.sendKeys(Keys.ENTER);
        WebElement selectGRINnoDropDownFocusedElement = driver.switchTo().activeElement();
        boolean selectGRINnoDropDownIsSelected = selectGRINnoDropDownFocusedElement.equals(selectGRINnoDropDown);
        assertTrue(selectGRINnoDropDownIsSelected, "Select GRIN No. Drop Down is not Selected");
        WebElement selectGRINnoDropDownValue = driver.findElement(By.xpath(updatedXpath));
        click(driver, selectGRINnoDropDownValue);
        
//Vender Name
	
		String venderNameQtyxpath = "//label[text()='Vendor Name']/..//label[@class='field2']";
		
		String venderNameQty = driver.findElement(By.xpath(venderNameQtyxpath)).getText();
		
		System.out.println("Vender Name is : "+venderNameQty);
		Thread.sleep(2000); 
      		
        
//Vender Id
	
		String venderIdQtyxpath = "//label[text()='Vendor Name']/..//label[@class='field2']";
		
		String venderIdQty = driver.findElement(By.xpath(venderIdQtyxpath)).getText();
		
		System.out.println("Vender Id is : "+venderIdQty);
		Thread.sleep(2000); 
      				
//Invoice Number 
		
		String invoiceNumberxpath = "//label[text()='Invoice Number']/..//label[@class='field2']";
		
		String invoiceNumber = driver.findElement(By.xpath(invoiceNumberxpath)).getText();
		
		System.out.println("Invoice Number  is : "+invoiceNumber);
		Thread.sleep(2000); 
		
//Invoice Date 

		String invoiceDatexpath = "//label[text()='Invoice Date']/..//label[@class='field2']";
		
		String invoiceDate = driver.findElement(By.xpath(invoiceDatexpath)).getText();
		
		System.out.println("Invoice Date  is : "+invoiceDate);
		Thread.sleep(2000); 
		
//Invoice Value (without GST) 

		String invoiceValuexpath = "//label[text()='Invoice Value (without GST)']/..//label[@class='field2']";
		
		String invoiceValue = driver.findElement(By.xpath(invoiceValuexpath)).getText();
		
		System.out.println("Invoice Date  is : "+invoiceValue);
		Thread.sleep(2000); 
		WebElement table = driver.findElement(By.cssSelector("table[class='table mb-2']"));

		//Get header row
		WebElement headerRow = table.findElement(By.cssSelector("tr[class='itemTableHeadTr']"));

		//Get headers  
		List<WebElement> headers = headerRow.findElements(By.tagName("th"));

		//Get data rows
		List<WebElement> rows = table.findElements(By.cssSelector("tr:not(.itemTableHeadTr)"));

		//Iterate over rows
		for(WebElement row : rows) {

		  //Get cells
		  List<WebElement> cells = row.findElements(By.tagName("td"));
		  
		  //Print cell data
		  for(int i=0; i<cells.size(); i++){
		    System.out.println(headers.get(i).getText() + " : " + cells.get(i).getText());  
		    
		  }

		}
		

		click(driver, binning);
		
		 //Verify that  projectNum Field is Displayed or not
  		boolean isDisabledprojectNumFieldn = !projectNum.isDisplayed(); 
  		Assert.assertFalse(isDisabledprojectNumFieldn);
  		
  		click(driver, projectNum);     
          
  	  WebElement projectNumSelect = driver.findElement(By.xpath(updatedXpath2));
		
		js.executeScript("arguments[0].click();", projectNumSelect);
		
		//Verify that  warehouse Field is Displayed or not
				boolean isDisabledwarehouseFieldn = !warehouse.isDisplayed(); 
				Assert.assertFalse(isDisabledwarehouseFieldn);
				

				//Verify that  warehouse Field is clickable or not
		  		WebElement warehouseFieldFocusedElement = driver.switchTo().activeElement();
			    boolean warehouseFieldIsSelected = warehouseFieldFocusedElement.equals(warehouse);
			    Assert.assertFalse(warehouseFieldIsSelected, "warehouse Text Field is not Selected");
			    
				warehouse.sendKeys(Keys.ENTER);
				js.executeScript("arguments[0].click()", warehouseSelect);
				
				//Verify that  location Field is Displayed or not
				boolean isDisabledlocationFieldn = !location.isDisplayed(); 
				Assert.assertFalse(isDisabledlocationFieldn);
				

				//Verify that  location Field is clickable or not
		  		WebElement locationFieldFocusedElement = driver.switchTo().activeElement();
			    boolean locationFieldIsSelected = locationFieldFocusedElement.equals(location);
			    Assert.assertFalse(locationFieldIsSelected, "location Text Field is not Selected");
			    
				location.sendKeys(Keys.ENTER);
				js.executeScript("arguments[0].click()", locationSelect);
				
				quantity.sendKeys("10");
				click(driver, add);
				click(driver, save);
				click(driver, save1);
		return new HomePage();
	}

}
