package com.getapcs.Transaction;


import static org.testng.Assert.assertFalse;
import static org.testng.Assert.assertTrue;

import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;
import org.testng.Assert;

import com.getapcs.base.Testbase1;
import com.getapcs.pages.HomePage;

public class DeliveryOrder  extends Testbase1 {
	
	//Delivery Order
	
	@FindBy(xpath = "(//input[@type='text'])[1]")
	WebElement customerNameDropDown;
	
	@FindBy(xpath = "(//span[normalize-space()='0003 - Test comName'])[1]")
	WebElement customerNameDropDownSelect;

	@FindBy(xpath = "(//input[@type='text'])[4]")
	WebElement salesOrderNum;
	
	@FindBy(xpath = "(//input[@placeholder='Accepted Qty'])[1]")
	WebElement acceptedQty;

	@FindBy(xpath = "//button[normalize-space()='Save']")
	WebElement saveButton;
	
	public DeliveryOrder() {
	   
	    PageFactory.initElements(driver, this);
	}

//*************Shop Order Create Page******************
	
	public HomePage DeliveryOrderCreate() throws InterruptedException {
		// TODO Auto-generated method stub
		System.out.println("//*************Delivery Order Create Page******************");
		driver.navigate().to("https://demo_keus.getapcs.com/transaction/sales-order/table");
		
	    String tableXpath = "//table[@class='table table-striped']";
	    
	    //Get the first PR number text from table 
	    String salesOrderNumber = driver.findElement(By.xpath(tableXpath+"/tbody/tr[1]/td[2]")).getText();
	    
	    //Store the element with hard coded PR number 
	    String elementXpath = "(//span[normalize-space()='Item-FG-11-TEST'])[1]";
	    
	    String updatedXpath = elementXpath.replace("Item-FG-11-TEST", salesOrderNumber);
	    
	    System.out.println(updatedXpath);
	    
	    
	 
	  //Customer Name 
        
		//Click on Customer Name Drop Down RFQ Create Page-Sales Module
	    boolean customerNameDropDownIsDisplayed = customerNameDropDown.isDisplayed();
	    assertTrue(customerNameDropDownIsDisplayed, "Customer Name Drop Down is not Displayed.");
	    customerNameDropDown.sendKeys(Keys.ENTER);
	    js.executeScript("arguments[0].click();", customerNameDropDownSelect);
	   

//sales Order Number
		
	  //Verify that  salesOrderNum Field is Displayed or not
  		boolean isDisabledsalesOrderNumFieldn = !salesOrderNum.isDisplayed(); 
  		Assert.assertFalse(isDisabledsalesOrderNumFieldn);
  		
  		js.executeScript("arguments[0].scrollIntoView(true);", salesOrderNum);
  		salesOrderNum.click();
  		
  		//Verify that  salesOrderNum Field is clickable or not
  		WebElement salesOrderNumFieldFocusedElement = driver.switchTo().activeElement();
  	    boolean salesOrderNumFieldIsSelected = salesOrderNumFieldFocusedElement.equals(salesOrderNum);
  	    Assert.assertTrue(salesOrderNumFieldIsSelected, "salesOrderNum Text Field is not Selected");	  	    
          
  	  WebElement salesOrderNum = driver.findElement(By.xpath(updatedXpath));
		
		js.executeScript("arguments[0].click();", salesOrderNum);


//customerId

		String customerIdxpath = "//label[text()='Customer Id']/..//input[@class='form-control ng-pristine ng-valid ng-touched']";
		
		String customerId = driver.findElement(By.xpath(customerIdxpath)).getText();
		
		System.out.println("customerId is : "+customerId);
		Thread.sleep(2000); 
  			
//customerAliasName

		String customerAliasNamexpath = "//label[text()='Customer Alias Name']/..//div[@class='form-group field2']";
		
		String customerAliasName = driver.findElement(By.xpath(customerAliasNamexpath)).getText();
		
		System.out.println("customerAliasNameis : "+customerAliasName);
		Thread.sleep(2000); 
		
//shopOrderRevNo

		String shopOrderRevNoxpath = "//label[text()='Sales order Rev no']/..//div[@class='form-group field2']";
		
		String shopOrderRevNo = driver.findElement(By.xpath(shopOrderRevNoxpath)).getText();
		
		System.out.println("shopOrderRevNois : "+shopOrderRevNo);
		Thread.sleep(2000); 
		
//poNumber

		String poNumberxpath = "//label[text()='PO Number']/..//div[@class='form-group field2']";
		
		String poNumber = driver.findElement(By.xpath(poNumberxpath)).getText();
		
		System.out.println("poNumberis : "+poNumber);
		Thread.sleep(2000); 
		
//prouctType

		String prouctTypexpath = "//label[text()='Prouct Type']/..//div[@class='field2 form-group input-group']";
		
		String prouctType = driver.findElement(By.xpath(prouctTypexpath)).getText();
		
		System.out.println("prouctTypeis : "+prouctType);
		Thread.sleep(2000); 
		
//typeOfSolution

		String typeOfSolutionxpath = "//label[text()='Type Of Solution']/..//div[@class='field2 form-group input-group']";
		
		String typeOfSolution = driver.findElement(By.xpath(typeOfSolutionxpath)).getText();
		
		System.out.println("typeOfSolutionis : "+typeOfSolution);
		Thread.sleep(2000); 
		
//doDate

		String doDatexpath = "//label[text()='DO Date']/..//div[@class='form-group field2']";
		
		String doDate = driver.findElement(By.xpath(doDatexpath)).getText();
		
		System.out.println("doDateis : "+doDate);
		Thread.sleep(2000); 
		
//orderType

		String orderTypexpath = "//label[text()='Order Type']/..//div[@class='field2 form-group input-group']";
		
		String orderType = driver.findElement(By.xpath(orderTypexpath)).getText();
		
		System.out.println("orderTypeis : "+orderType);
		Thread.sleep(2000); 
		
//soValue

		String soValuexpath = "//label[text()='SO Value']/..//div[@class='field2 form-group input-group']";
		
		String soValue = driver.findElement(By.xpath(soValuexpath)).getText();
		
		System.out.println("soValueis : "+soValue);
		Thread.sleep(2000); 
		
//advanceValue

		String advanceValuexpath = "//label[text()='Advance Value']/..//div[@class='field2 form-group input-group']";
		
		String advanceValue = driver.findElement(By.xpath(advanceValuexpath)).getText();
		
		System.out.println("advanceValueis : "+advanceValue);
		Thread.sleep(2000); 
		
//alreadyDispatchedValue

		String alreadyDispatchedValuexpath = "//label[text()='Already Dispatched Value']/..//div[@class='field2 form-group input-group']";
		
		String alreadyDispatchedValue = driver.findElement(By.xpath(alreadyDispatchedValuexpath)).getText();
		
		System.out.println("alreadyDispatchedValueis : "+alreadyDispatchedValue);
		Thread.sleep(2000); 
		
		
//balanceAdvanceValue

		String balanceAdvanceValuexpath = "//label[text()='Balance Advance Value']/..//div[@class='field2 form-group input-group']";
		
		String balanceAdvanceValue = driver.findElement(By.xpath(balanceAdvanceValuexpath)).getText();
		
		System.out.println("balanceAdvanceValueis : "+balanceAdvanceValue);
		Thread.sleep(2000); 
		
//dispatchValue

		String dispatchValuexpath = "//label[text()='Dispatch Value']/..//div[@class='field2 form-group input-group']";
		
		String dispatchValue = driver.findElement(By.xpath(dispatchValuexpath)).getText();
		
		System.out.println("dispatchValueis : "+dispatchValue);
		Thread.sleep(2000); 
		
//Table 
	
//      
////Release Qty
//        
//       //Verify that  acceptedQty Field is Displayed or not
//		boolean isDisabledacceptedQtyFieldn = !acceptedQty.isDisplayed(); 
//		assertFalse(isDisabledacceptedQtyFieldn);
//		
//		//Verify that  acceptedQty Field is clickable or not
// 		WebElement acceptedQtyFieldFocusedElement = driver.switchTo().activeElement();
//	    boolean acceptedQtyFieldIsSelected = acceptedQtyFieldFocusedElement.equals(acceptedQty);
//	    assertFalse(acceptedQtyFieldIsSelected, "acceptedQty Text Field is not Selected");
//         
//	    //Verifying that acceptedQty Text Field is Enabled or not
// 		boolean isEnabledacceptedQtyField = acceptedQty.isEnabled();
// 		assertTrue(isEnabledacceptedQtyField);
//
// 		acceptedQty.sendKeys("1");
//	
		
//Save Button
	     
	     //Verify and Click on Save Button in Create-Item PriceList-Sales Module
	       boolean saveButtonIsDisplayed = saveButton.isDisplayed();
	       assertTrue(saveButtonIsDisplayed, "Save Button is not Displayed");
	       saveButton.click();
	     
		return new HomePage();
	}

}
